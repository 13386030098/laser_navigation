^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pepperl_fuchs_r2000
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.3 (2016-09-15)
------------------
* Initial release
* Contributors: Denis Dillenberger, Kevin Hallenbeck
